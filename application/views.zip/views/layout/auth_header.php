<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Login | HES Officer Dashboard</title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?= base_url('assets/html/'); ?>assets/images/favicon.ico" />
      <link rel="stylesheet" href="<?= base_url('assets/html/'); ?>assets/css/backend-plugin.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/html/'); ?>assets/css/backend.css?v=1.0.0">
      <link rel="stylesheet" href="<?= base_url('assets/html/'); ?>assets/vendor/@fortawesome/fontawesome-free/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/html/'); ?>assets/vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/html/'); ?>assets/vendor/remixicon/fonts/remixicon.css">  
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </head>
  <body class=" ">