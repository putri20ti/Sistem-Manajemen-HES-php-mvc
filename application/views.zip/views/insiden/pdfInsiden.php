<!DOCTYPE html>
<html>

<head>
    <title>Data Insiden Kerja</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Poppins:wght@200;400&display=swap" rel="stylesheet">
    <style>
        * {
            font-family: 'Montserrat', sans-serif;
        }

        html {
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
        }

        body {
            padding: 20px;
        }

        h3 {
            font-family: 'Montserrat', sans-serif;
            text-align: center;
        }

        .section {
            font-family: 'Montserrat', sans-serif;
            margin-bottom: 20px;
        }

        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 14px;
            font-weight: bold;
            color: blue;
            margin-bottom: 10px;
        }

        .section-content {
            font-family: 'Montserrat', sans-serif;
            font-size: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 10px;
        }

        th,
        td {
            border: 1px solid black;
            text-align: left;
            padding: 4px;
        }

        th {
            background-color: #f2f2f2;
        }

        .table-title {
            font-weight: bold;
            background-color: #004080;
            color: white;
            text-align: center;
        }

        .center-text {
            text-align: center;
        }

        .full-width {
            background-color: #004080;
            color: white;
            text-align: center;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <h3>DATA INSIDEN KERJA</h3>
    <div class="section">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Nama Karyawan</th>
                    <th>No Badge</th>
                    <th>Jabatan</th>
                    <th>Uraian</th>
                    <th>Penyebab</th>
                    <th>Tingkat Insiden</th>
                    <th>NLTI</th>
                    <th>TLI</th>
                    <th>Day Lost</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($insiden_kerja as $insiden): ?>
                <tr>
                    <td class="center-text"><?= $no++; ?></td>
                    <td class="center-text"><?= $insiden['tanggal']; ?></td>
                    <td><?= $insiden['nama_karyawan']; ?></td>
                    <td><?= $insiden['nobadge']; ?></td>
                    <td><?= $insiden['jabatan']; ?></td>
                    <td><?= $insiden['uraian']; ?></td>
                    <td><?= $insiden['penyebab']; ?></td>
                    <td><?= $insiden['tingkat_insiden']; ?></td>
                    <td><?= $insiden['nlti']; ?></td>
                    <td><?= $insiden['tli']; ?></td>
                    <td><?= $insiden['day_lost']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>

</html>
